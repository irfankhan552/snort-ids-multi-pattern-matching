#! /bin/sh

DUMPS_DIR=../../testdumps
RESULTS=./results2

mkdir $RESULTS
rm
rm /var/log/snort/*

rm $RESULTS/*

for file in `ls $DUMPS_DIR`; do
 i=1
 while [ $i -le 50 ]; do
  # only print out the times into the results file:

  echo "--------------"  
  echo "Run number: $i"
  echo "--------------"
  sleep 1
  
  ./snort -r $DUMPS_DIR/$file -A none -c ./snort.conf.ac-banded | \
    grep "Run time" | sed s/"Run time for packet processing was "// | sed s/" seconds"// >> $RESULTS/AC-BANDED_RESULTS.$file.txt
  
  ./snort -r $DUMPS_DIR/$file -A none -c ./snort.conf.ac | \
    grep "Run time" | sed s/"Run time for packet processing was "// | sed s/" seconds"// >> $RESULTS/AC-FULL_RESULTS.$file.txt
      
  ./snort -r $DUMPS_DIR/$file -A none -c ./snort.conf.ac-std | \
    grep "Run time" | sed s/"Run time for packet processing was "// | sed s/" seconds"// >> $RESULTS/AC-STD_RESULTS.$file.txt
  
  ./snort -r $DUMPS_DIR/$file -A none -c ./snort.conf.mbom | \
    grep "Run time" | sed s/"Run time for packet processing was "// | sed s/" seconds"// >> $RESULTS/MBOM_RESULTS.$file.txt
  
  ./snort -r $DUMPS_DIR/$file -A none -c ./snort.conf.mbom2 | \
    grep "Run time" | sed s/"Run time for packet processing was "// | sed s/" seconds"// >> $RESULTS/MBOM2_RESULTS.$file.txt
    
  ./snort -r $DUMPS_DIR/$file -A none -c ./snort.conf.auto | \
    grep "Run time" | sed s/"Run time for packet processing was "// | sed s/" seconds"// >> $RESULTS/AUTO_RESULTS.$file.txt
  
  i=`expr $i + 1`
  
  rm /var/log/snort/*
  
 done;

 ./process_average $RESULTS/AC-FULL_RESULTS.$file.txt >  $RESULTS/ALL_AVERAGE_RESULTS.$file.txt
 ./process_average $RESULTS/AC-BANDED_RESULTS.$file.txt >> $RESULTS/ALL_AVERAGE_RESULTS.$file.txt
 ./process_average $RESULTS/AC-STD_RESULTS.$file.txt >> $RESULTS/ALL_AVERAGE_RESULTS.$file.txt
 ./process_average $RESULTS/MBOM_RESULTS.$file.txt >> $RESULTS/ALL_AVERAGE_RESULTS.$file.txt
 ./process_average $RESULTS/MBOM2_RESULTS.$file.txt >> $RESULTS/ALL_AVERAGE_RESULTS.$file.txt
 ./process_average $RESULTS/AUTO_RESULTS.$file.txt >> $RESULTS/ALL_AVERAGE_RESULTS.$file.txt

done;

exit 0
