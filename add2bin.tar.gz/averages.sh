#! /bin/sh
RESULTS=./results

for file in `ls $RESULTS`; do
 ./process_average.pl $RESULTS/$file > $RESULTS/Average.$file
done;

exit 0
