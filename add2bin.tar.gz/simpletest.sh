#! /bin/sh

DUMPS_DIR=../testdumps
RESULTS=./simpleresults

mkdir $RESULTS
rm -f /var/log/snort/*

rm -f $RESULTS/AC-FULL_RESULTS.$file.txt
rm -f $RESULTS/AC-BANDED_RESULTS.$file.txt
rm -f $RESULTS/AC-STD_RESULTS.$file.txt
rm -f $RESULTS/MBOM_RESULTS.$file.txt
rm -f $RESULTS/MBOM2_RESULTS.$file.txt
rm -f $RESULTS/AUTO_RESULTS.$file.txt

for file in `ls $DUMPS_DIR`
do
  ./snort -r $DUMPS_DIR/$file -A fast -c ./snort.conf.ac
  mv /var/log/snort/alert $RESULTS/snort.alert.ac.$file

  ./snort -r $DUMPS_DIR/$file -A fast -c ./snort.conf.ac-banded
  mv /var/log/snort/alert $RESULTS/snort.alert.ac-banded.$file

  ./snort -r $DUMPS_DIR/$file -A fast -c ./snort.conf.ac-std
  mv /var/log/snort/alert $RESULTS/snort.alert.std.$file
  
  ./snort -r $DUMPS_DIR/$file -A fast -c ./snort.conf.mbom
  mv /var/log/snort/alert $RESULTS/snort.alert.mbom.$file
  
  ./snort -r $DUMPS_DIR/$file -A fast -c ./snort.conf.mbom2
  mv /var/log/snort/alert $RESULTS/snort.alert.mbom2.$file
  
  ./snort -r $DUMPS_DIR/$file -A fast -c ./snort.conf.auto
  mv /var/log/snort/alert $RESULTS/snort.alert.auto.$file

done;

exit 0
