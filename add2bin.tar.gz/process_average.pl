#! /usr/bin/perl -w

$sum=0.0;
$num=0.0;

open(MYFILE,$ARGV[0]) or die "Can't open ". $ARGV[0]. "\n";
while (<MYFILE>) {
   $sum += $_;
   $num++;
}
close MYFILE;
print "Average in ". $ARGV[0] . " was: ". ($sum / $num). "\n";
